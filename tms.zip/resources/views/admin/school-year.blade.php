@section('title', 'School Year')
<x-admin-layout>
    <div>
        <livewire:admin.school-year-list />
    </div>
</x-admin-layout>
