@section('title', 'Colleges')
<x-admin-layout>
    <div>
        <livewire:admin.college-list />
    </div>
</x-admin-layout>
