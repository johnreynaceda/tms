@section('title', 'Program Chairs')
<x-admin-layout>
    <div>
        <livewire:admin.admin-program-chair />
    </div>
</x-admin-layout>
