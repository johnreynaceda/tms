@section('title', 'Deans')
<x-admin-layout>
    <div>
        <livewire:admin.dean-list />
    </div>
</x-admin-layout>
