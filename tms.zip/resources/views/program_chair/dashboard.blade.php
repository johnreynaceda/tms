@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        <livewire:program-chair-dashboard />
    </div>
</x-admin-layout>
