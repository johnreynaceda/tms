@section('title', 'Repositories')
<x-admin-layout>
    <div>
        <livewire:program_chair.repository-list />
    </div>
</x-admin-layout>
