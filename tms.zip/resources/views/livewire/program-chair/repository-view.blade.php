@section('title', 'View Repository')
<div>
    <div>
        <a href="{{ auth()->user()->user_type == 'program_chair' ? route('program_chair.repository') : route('teacher.repository') }}"
            x-navigate class="flex space-x-2 items-center mb-6 text-gray-700 hover:text-red-600">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none"
                stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                class="lucide lucide-arrow-left">
                <path d="m12 19-7-7 7-7" />
                <path d="M19 12H5" />
            </svg>
            <span class="font-semibold">BACK</span>
        </a>
        {{-- <div class="mt-12">
            <div class="grid grid-cols-3 divide-x-2 border gap-5">
                <div class="py-2">
                    <h1 class="font-semibold uppercase px-5 border-b text-green-700">Students</h1>
                    <ul class="mt-4 px-4">
                        @foreach ($students as $item)
                            <li>{{ $item->student->firstname . ' ' . $item->student->lastname }}</li>
                        @endforeach
                    </ul>
                </div>
                <div class="py-2">
                    <h1 class="font-semibold uppercase px-5 border-b text-green-700">Adviser</h1>
                    <ul class="mt-4 px-4">
                        @foreach ($advisers as $item)
                            <li>{{ $item->teacher->firstname . ' ' . $item->teacher->lastname }}</li>
                        @endforeach
                    </ul>
                </div>
                <div class="py-2">
                    <h1 class="font-semibold uppercase px-5 border-b text-green-700">Panelist</h1>
                    <ul class="mt-4 px-4">
                        <li>sdsdsd</li>
                    </ul>
                </div>
            </div>
        </div> --}}
        <div class="mt-10 grid grid-cols-5 gap-10">
            <div class="col-span-3">
                <div class="h1 text-2xl text-left text-gray-700 uppercase font-semibold">TITLE: {{ $repository_name }}
                </div>

                <div class="mt-5">
                    <div class="flex space-x-2 text-green-600 border-b">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="lucide lucide-users">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                            <circle cx="9" cy="7" r="4" />
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                        </svg>
                        <span class="font-semibold ">GROUP MEMBER</span>
                    </div>
                    <div class="mt-2">
                        <ul>
                            @foreach ($students as $item)
                                <li>{{ $item->student->lastname . ', ' . $item->student->firstname }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <div class="mt-5">
                    <div class="flex space-x-2 text-green-600 border-b">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="lucide lucide-users">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                            <circle cx="9" cy="7" r="4" />
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                        </svg>
                        <span class="font-semibold ">ADVISER</span>
                    </div>
                    <div class="mt-2">
                        <ul>
                            @foreach ($advisers as $item)
                                <li>{{ $item->teacher->lastname . ', ' . $item->teacher->firstname }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
                <div class="mt-5">
                    <div class="flex space-x-2 text-green-600 border-b">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="lucide lucide-users">
                            <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
                            <circle cx="9" cy="7" r="4" />
                            <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
                            <path d="M16 3.13a4 4 0 0 1 0 7.75" />
                        </svg>
                        <span class="font-semibold ">PANELISTS</span>
                    </div>
                    <div class="mt-2">
                        <ul>
                            @foreach ($panels as $item)
                                <li>{{ $item->teacher->lastname . ', ' . $item->teacher->firstname }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-span-2">
                <div class="bg-gray-100 shadow-md h-96 overflow-y-auto relative  rounded-xl">
                    <div class="flex bg-gray-100 p-5 sticky top-0  space-x-3 text-green-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="lucide lucide-file-check-2">
                            <path d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4" />
                            <path d="M14 2v4a2 2 0 0 0 2 2h4" />
                            <path d="m3 15 2 2 4-4" />
                        </svg>
                        <span class="font-semibold">UPLOADED DOCUMENTS</span>
                    </div>
                    <ul class=" px-5 pb-5 space-y-2">
                        @forelse ($documents as $item)
                            <li class="bg-white shadow-sm rounded-lg p-2 px-4 ">
                                <div class="text-right text-xs justify-end">
                                    {{ \Carbon\Carbon::parse($item->created_at)->diffForHumans() }}</div>
                                <div class="flex mt-2 justify-between space-x-2">
                                    <div class="flex space-x-2 text-gray-700 ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                                            stroke-linecap="round" stroke-linejoin="round"
                                            class="lucide lucide-file-type-2">
                                            <path d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4" />
                                            <path d="M14 2v4a2 2 0 0 0 2 2h4" />
                                            <path d="M2 13v-1h6v1" />
                                            <path d="M5 12v6" />
                                            <path d="M4 18h2" />
                                        </svg>
                                        <p class="truncate w-64">{{ $item->name }}</p>
                                    </div>
                                    <x-button href="{{ Storage::url($item->document_path) }}" target="_blank" xs
                                        color="green" icon="eye" position="right">View</x-button>
                                </div>
                            </li>
                        @empty

                            No uploaded documents yet.
                        @endforelse

                    </ul>
                </div>
            </div>
        </div>
        <div class="grid grid-cols-5 gap-10 mt-5">
            <div class=" col-span-3 border-t pt-5 ">
                <div class="flex space-x-2 items-center text-green-600">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                        fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" class="lucide lucide-file-badge">
                        <path d="M12 22h6a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v3" />
                        <path d="M14 2v4a2 2 0 0 0 2 2h4" />
                        <path d="M5 17a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                        <path d="M7 16.5 8 22l-3-1-3 1 1-5.5" />
                    </svg>
                    <h1 class="text-2xl  font-bold">GRADINGS</h1>
                </div>
                <div class="mt-5 space-y-10 ">
                    <div class="">
                        <div class="flex space-x-10  ">
                            <h1 class="text-lg font-semibold text-gray-600 underline w-full">OUTLINE DEFENSE</h1>
                            @php
                                $alreadyAdded = \App\Models\RepositoryGrade::where('repository_id', $repository_id)
                                    ->where('type_of_defense', 'Outline')
                                    ->where('teacher_id', auth()->user()->teacher->id)
                                    ->get()
                                    ->count();
                            @endphp
                            @if (auth()->user()->user_type == 'teacher')
                                @if ($alreadyAdded == 0)
                                    <x-button icon="plus" wire:click="$set('outline_modal', true)" color="emerald"
                                        xs>Add</x-button>
                                @endif
                            @endif
                        </div>
                        <ul class="mt-2">
                            @forelse ($outlines as $item)
                                <li>{{ $item->teacher->lastname . ', ' . $item->teacher->firstname }} =
                                    <strong class="text-2xl text-blue-500">{{ $item->grade }}</strong>
                                </li>
                            @empty
                                <li>No Grade Submitted..</li>
                            @endforelse
                        </ul>
                    </div>
                    <div>
                        <div class="flex space-x-10">
                            <h1 class="text-lg font-semibold text-gray-600 underline w-full">FINAL DEFENSE</h1>
                            @php
                                $alreadyAdded = \App\Models\RepositoryGrade::where('repository_id', $repository_id)
                                    ->where('type_of_defense', 'Final')
                                    ->where('teacher_id', auth()->user()->teacher->id)
                                    ->get()
                                    ->count();
                            @endphp
                            @if (auth()->user()->user_type == 'teacher')
                                @if ($alreadyAdded == 0)
                                    <x-button icon="plus" wire:click="$set('final_modal', true)" color="emerald"
                                        xs>Add</x-button>
                                @endif
                            @endif
                        </div>
                        <ul class="mt-2">
                            @forelse ($finals as $item)
                                <li>{{ $item->teacher->lastname . ', ' . $item->teacher->firstname }} =
                                    <strong class="text-2xl text-blue-500">{{ $item->grade }}</strong>
                                </li>
                            @empty
                                <li>No Grade Submitted..</li>
                            @endforelse
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-span-2">
                <div class="bg-gray-100 shadow-md h-96 overflow-y-auto relative  rounded-xl">
                    <div class="flex bg-gray-100 p-5 sticky top-0  space-x-3 text-green-600">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="lucide lucide-file-check-2">
                            <path d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4" />
                            <path d="M14 2v4a2 2 0 0 0 2 2h4" />
                            <path d="m3 15 2 2 4-4" />
                        </svg>
                        <span class="font-semibold">UPLOADED PAYMENTS</span>
                    </div>
                    <ul class=" px-5 pb-5 space-y-2">
                        @forelse ($payments as $item)
                            <li class="bg-white shadow-sm rounded-lg p-2 px-4 ">
                                <div class="text-right text-xs justify-end">3 hours ago</div>
                                <div class="flex mt-2 justify-between space-x-2">
                                    <div class="flex space-x-2 text-gray-700 ">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                            viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                            stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                                            class="lucide lucide-file-type-2">
                                            <path d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4" />
                                            <path d="M14 2v4a2 2 0 0 0 2 2h4" />
                                            <path d="M2 13v-1h6v1" />
                                            <path d="M5 12v6" />
                                            <path d="M4 18h2" />
                                        </svg>
                                        <p class="truncate w-64">{{ $item->name }}</p>
                                    </div>
                                    <x-button href="{{ Storage::url($item->document_path) }}" target="_blank" xs
                                        color="green" icon="eye" position="right">View</x-button>
                                </div>
                            </li>
                        @empty

                            No uploaded documents yet.
                        @endforelse

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <x-modal wire="outline_modal" center>
        <div class="px-5 pt-5 pb-3">
            <h1 class="font-bold text-xl text-gray-600">OUTLINE DEFENSE GRADE</h1>
            <div class="mt-5">
                <x-input label="Grade" type="number" wire:model="outline_grade"
                    hint="Enter grade you want to give." />
            </div>
            <div class="mt-5">
                <x-button color="emerald" wire:click="outlineSubmit" sm>Submit Grade</x-button>
            </div>
        </div>
    </x-modal>
    <x-modal wire="final_modal" center>
        <div class="px-5 pt-5 pb-3">
            <h1 class="font-bold text-xl text-gray-600">FINAL DEFENSE GRADE</h1>
            <div class="mt-5">
                <x-input label="Grade" type="number" wire:model="final_grade"
                    hint="Enter grade you want to give." />
            </div>
            <div class="mt-5">
                <x-button color="emerald" wire:click="finalSubmit" sm>Submit Grade</x-button>
            </div>
        </div>
    </x-modal>
</div>
