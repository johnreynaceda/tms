@section('title', 'Program Chairs')
<x-admin-layout>
    <div>
        <livewire:dean.program-chair-list />
    </div>
</x-admin-layout>
