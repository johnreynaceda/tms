@section('title', 'Repository')
<x-admin-layout>
    <div>
        <livewire:teacher-repository-list />
    </div>
</x-admin-layout>
