@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        <livewire:teacher-dashboard />
    </div>
</x-admin-layout>
