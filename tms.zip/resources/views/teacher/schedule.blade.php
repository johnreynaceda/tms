@section('title', 'Schedule')
<x-admin-layout>
    <div>
        <livewire:teacher.teacher-schedule />
    </div>
</x-admin-layout>
