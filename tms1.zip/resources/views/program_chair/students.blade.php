@section('title', 'Students')
<x-admin-layout>
    <div>
        <livewire:program_chair.student-list />
    </div>
</x-admin-layout>
