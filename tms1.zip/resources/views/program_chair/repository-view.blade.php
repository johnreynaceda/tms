<x-admin-layout>
    <div>
        <livewire:program_chair.repository-view />
    </div>
</x-admin-layout>
