@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        <livewire:dean-dashboard />
    </div>
</x-admin-layout>
