@section('title', 'Students')
<x-admin-layout>
    <div>
        <livewire:dean.dean-student />
    </div>
</x-admin-layout>
