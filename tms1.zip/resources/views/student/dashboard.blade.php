@section('title', 'Dashboard')
<x-admin-layout>
    <div>
        sdsdsd
    </div>
</x-admin-layout>
