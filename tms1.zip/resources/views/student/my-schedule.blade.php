@section('title', 'Schedules')
<x-admin-layout>
    <div>
        <livewire:student.schedule-list />
    </div>
</x-admin-layout>
