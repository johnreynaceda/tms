@section('title', 'My Repository')
<x-admin-layout>
    <div>
        <livewire:student.my-repository />
    </div>
</x-admin-layout>
