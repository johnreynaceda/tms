@section('title', 'Teachers')
<x-admin-layout>
    <div>
        <livewire:admin.teacher-list />
    </div>
</x-admin-layout>
