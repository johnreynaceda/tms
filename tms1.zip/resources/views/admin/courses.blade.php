@section('title', 'Courses')
<x-admin-layout>
    <div>
        <livewire:admin.course-list />
    </div>
</x-admin-layout>
