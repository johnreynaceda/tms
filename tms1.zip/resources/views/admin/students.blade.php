@section('title', 'Students')
<x-admin-layout>
    <div>
        <livewire:admin.admin-student />
    </div>
</x-admin-layout>
